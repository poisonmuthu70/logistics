class TypPosition < ActiveRecord::Base
	has_many :org_people
end
