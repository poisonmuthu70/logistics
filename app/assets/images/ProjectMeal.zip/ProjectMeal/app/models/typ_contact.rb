class TypContact < ActiveRecord::Base
	has_many :org_contacts
end
