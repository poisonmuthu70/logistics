class TypFee < ActiveRecord::Base
	has_many :TrxOrderFee
end
