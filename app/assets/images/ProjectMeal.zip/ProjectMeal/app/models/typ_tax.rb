class TypTax < ActiveRecord::Base
	has_many :typ_sales_taxes
end
