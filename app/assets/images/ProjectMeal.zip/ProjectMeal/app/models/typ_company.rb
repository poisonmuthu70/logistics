class TypCompany < ActiveRecord::Base
	has_many :org_companies
end
