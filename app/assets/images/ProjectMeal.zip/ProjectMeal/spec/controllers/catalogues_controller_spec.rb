require 'rails_helper'

RSpec.describe CataloguesController, type: :controller do

end
